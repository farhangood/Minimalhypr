#!/bin/bash
# Path ke wallpaper yang dipakai
WALL=~/wallpaper.jpg

# Folder tema SDDM SilentSDDM (ganti jika beda)
SDDM_THEME_DIR=/usr/share/sddm/themes/SilentSDDM

# Copy wallpaper ke background theme
if [[ -f "$WALL" && -d "$SDDM_THEME_DIR" ]]; then
    cp "$WALL" "$SDDM_THEME_DIR"/Backgrounds/wallpaper.jpg
fi
