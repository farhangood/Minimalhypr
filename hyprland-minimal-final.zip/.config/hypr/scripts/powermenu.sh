#!/bin/bash
choice=$(printf "󰐥 Shutdown\n Reboot\n󰍃 Logout" | rofi -dmenu -i -p "Power Menu:" -theme ~/.config/rofi/theme.rasi)

case "$choice" in
  "󰐥 Shutdown") systemctl poweroff ;;
  " Reboot") systemctl reboot ;;
  "󰍃 Logout") hyprctl dispatch exit ;;
esac
