#!/bin/bash
grim -g "$(slurp)" ~/Pictures/screenshot_$(date +'%Y-%m-%d_%H-%M-%S').png
notify-send "📸 Screenshot saved"
